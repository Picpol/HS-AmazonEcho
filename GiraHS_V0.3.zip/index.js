'use strict';

var REMOTE_CLOUD_BASE_PATH = '/';
var REMOTE_CLOUD_HOSTNAME = process.env.DYNDNS; // Dynamic DNS Hostname ohne http/https z.B.: alexa.meinDomainName.de
var REMOTE_CLOUD_PORT = process.env.PORT; // zu verwendender Port (> 1024), gleicher Int-Wert wie im Logikbaustein Eingang 2
var ACCESS_TOKEN = process.env.TOKEN; // zu verwendendes Access Token, gleicher String-Wert wie im Logikbaustein Eingang 3
var APP_ID = process.env.APPID; // optionaler Zugriffsschutz: bei Angabe des ID's des Custom Skills kann diese Lambda-Funktion nur von diesem aufgerufen werden

var https = require('https');
var Alexa = require('alexa-sdk');

var languageStrings = {
	"de-DE": {
		"translation": {
			// AMAZON
			"WELCOME_MESSAGE": "Hallo, ich bin zur Steuerung deines Smart Home bereit!",
			"HELP_MESSAGE": "Du kannst zum Beispiel fragen, Ist das Licht in der Küche an?, oder Wie ist die Temperatur im Wohnzimmer?, oder du kannst Beenden sagen... Was soll ich abfragen?",
			"HELP_REPROMPT": "Welchen Wert vom Smart Home soll ich abfragen?",
			"STOP_MESSAGE": "Auf Wiedersehen!",

			// Allgemeine Fehlermeldungen
			"ERR_SYSTEM": "Beim Zugriff auf den Gira Homeserver ist leider ein Systemfehler aufgetreten.",
			"ERR_NO_APPLIANCES": "Die Liste der KNX-Objekte ist leer. Bitte zuerst Kommando, Suche meine KNX-Objekte, sagen.",
			"ERR_JSON_EMPTY": "Die JSON-Konfiguration ist leer.",
			"ERR_ID_NOT_FOUND": "Zu dem ID %s wurde in der JSON-Konfiguration kein KNX-Objekt gefunden.",
			"ERR_ATTR_NOT_FOUND": "In der JSON-Konfiguration fehlt das Attribut %s.",
			"ERR_KO_NOT_FOUND": "Das in der JSON-Konfiguration angegebene KNX-Objekt %s wurde nicht gefunden.",

			// DISCOVERY
			"DIS_REQUEST_ERROR": "Bei der Suche nach den KNX-Objekten ist ein Fehler aufgetreten.",
			"DIS_MESSAGE": "Es wurden %s KNX-Objekte gefunden.",
			"DIS_0_MESSAGE": "Es wurden keine KNX-Objekte gefunden.",

			// CONTROL - GET
			"GET_OK": "%s %s %s %s %s %s.",
			"GET_PARAM_ERROR": "Um %s abzufragen, benötige ich die Parameter Objektname und/oder den Bereich.",
			"GET_NOT_FOUND_ERROR": "Ich konnte %s nicht abfragen, weil ich %s %s %s %s nicht finden konnte.",
			"GET_REQUEST_ERROR": "Ich konnte %s nicht abfragen, weil bei der Anfrage für %s %s %s %s ein Fehler zurückgemeldet wurde. %s",

			// CONTROL - SET
			"SET_OK": "Ok",
			"SET_ONOFF_PARAM_MISSING": "Du musst mir zusätzlich sagen, ob ich das Gerät ein oder ausschalten soll.",
			"SET_PERCENT_PARAM_MISSING": "Du musst mir zusätzlich den Prozentwert sagen.",
			"SET_PERCENT_PARAM_ILLEGAL": "Den Wert, %s kann ich nicht als Prozentwert verwenden.",
			"SET_OBJECT_PARAM_MISSING": "Du musst mir zusätzlich sagen was ich %s soll.",
			"SET_CMD_PARAM_ERROR": "Der Befehl, %s wird vom Gerät nicht unterstützt.",
			"SET_NOT_FOUND_ERROR": "Ich konnte %s %s %s %s nicht %s, weil ich das Gerät nicht finden konnte.",
			"SET_CMD_NOT_SUPPORTED": "Dieser Befehl funktioniert für das Gerät %s %s %s nicht.",
			"SET_REQUEST_ERROR": "Ich konnte %s %s %s %s nicht %s, weil bei dem Kommando ein Fehler zurückgemeldet wurde. %s",
		}
	}
}

var DOOR_WINDOW_2_STATE = {
	0: "geschlossen",
	1: "offen",
	2: "gekippt"
}

var PROPERTY_MAP = {
	"hell": "helligkeit",
	"lux": "helligkeit",
	"dunkel": "helligkeit",
	"warm": "temperatur",
	"kalt": "temperatur",
	"grad": "temperatur",
	"windig": "windstärke",
	"helligkeit": "helligkeit",
	"temperatur": "temperatur",
	"isttemperatur": "temperatur",
	"aktuelle temperatur": "temperatur",
	"solltemperatur": "solltemperatur",
	"hoch": "",
	"wert": ""
}

var ARTICLE_2_PRAEPOSITION = {
	"der": "im",
	"die": "in der",
	"das": "im"
}

exports.handler = function (event, context, callback) {
	log('EVENT', JSON.stringify(event));

	if (event.header != null) {
		handleSmartHomeSkill(event, context);
	} else {
		handleCustomSkill(event, context, callback);
	}
}

function handleCustomSkill(event, context, callback) {

	// DISCOVERY
	var discoveryHandlers = {
		'DiscoverAppliances': function () {
			handleDiscovery(this);
		}
	};

	// CONTROL
	function returnValue(value, unit) {
		return formatValue(value, unit);
	}

	function returnCountValue(value, unit) {
		if (unit != null && unit.toLowerCase() === "mal") {
			return value > 0 ? (value > 1 ? value + " mal" : "ein mal") : "kein mal";
		} else {
			return value > 0 ? value : "keine";
		}
	}

	function returnOnOffValue(value, unit) {
		return value > 0 ? "an" : "aus";
	}

	function returnPercentValue(value, unit) {
		return formatValue(value, ",0 prozent");
	}

	function returnDoorWindowState(value, unit) {
		var state = DOOR_WINDOW_2_STATE[value];
		if (state == null) {
			state = "in einem unbekannten Zustand";
		}
		return state;
	}

	function returnTemperatureValue(value, unit) {
		return formatValue(value, ",1 grad");
	}

	var GET_PARAMS = {
		"GetText": ["GetTextRequest", "GetTextConfirmation", "text", null, returnValue, "den Statusbericht", ""],
		"GetValue": ["GetValueRequest", "GetValueConfirmation", "value", "VALUE_MESSAGE", returnValue, "den Wert", "beträgt"],
		"GetCountValue": ["GetValueRequest", "GetValueConfirmation", "value", null, returnCountValue, "die Anzahl", ""],
		"GetOnOffValue": ["GetOnOffValueRequest", "GetOnOffValueConfirmation", "onOff", "ONOFF_MESSAGE", returnOnOffValue, "den An/Aus Status", "ist"],
		"GetPercentValue": ["GetPercentValueRequest", "GetPercentValueConfirmation", "percent", "PERCENT_MESSAGE", returnPercentValue, "den Prozentwert", "steht auf"],
		"GetDoorWindowState": ["GetValueRequest", "GetValueConfirmation", "value", "DOOR_WINDOW_STATE_MESSAGE", returnDoorWindowState, "den Tür/Fensterstatus", "ist"],
		"GetTargetTemperature": ["GetTargetTemperatureRequest", "GetTargetTemperatureConfirmation", "targetTemperature", "VALUE_MESSAGE", returnTemperatureValue, "die Solltemperatur", "beträgt"],
		"GetActualTemperature": ["GetActualTemperatureRequest", "GetActualTemperatureConfirmation", "actualTemperature", "VALUE_MESSAGE", returnTemperatureValue, "die aktuelle Temperatur", "beträgt"]
	};

	var SET_PARAMS = {
		"SetOn": ["TurnOnRequest", "TurnOnConfirmation", "einschalten"],
		"SetOff": ["TurnOffRequest", "TurnOffConfirmation", "ausschalten"],
		"SetPercent": ["SetPercentageRequest", "SetPercentageConfirmation", "dimmen"]
	};

	var controlHandlers = {
		'GetText': function () {
			handleGetRequest(this, GET_PARAMS['GetText']);
		},
		'GetValue': function () {
			handleGetRequest(this, GET_PARAMS['GetValue']);
		},
		'GetCountValue': function () {
			handleGetRequest(this, GET_PARAMS['GetCountValue']);
		},
		'GetOnOffValue': function () {
			handleGetRequest(this, GET_PARAMS['GetOnOffValue']);
		},
		'GetPercentValue': function () {
			handleGetRequest(this, GET_PARAMS['GetPercentValue']);
		},
		'GetDoorWindowState': function () {
			handleGetRequest(this, GET_PARAMS['GetDoorWindowState']);
		},
		'GetTargetTemperature': function () {
			handleGetRequest(this, GET_PARAMS['GetTargetTemperature']);
		},
		'SetOnOffValue': function () {
			handleSetOnOffRequest(this);
		},
		'SetPercentValue': function () {
			handleSetPercentRequest(this);
		},

		'LaunchRequest': function () {
			this.attributes['IN_SESSION'] = "1";
			this.emit(':ask', this.t('WELCOME_MESSAGE'), this.t('HELP_MESSAGE'));
		},
		'AMAZON.HelpIntent': function () {
			var speechOutput = this.t("HELP_MESSAGE");
			var reprompt = this.t("HELP_REPROMPT");
			this.emit(':ask', speechOutput, reprompt);
		},
		'AMAZON.CancelIntent': function () {
			this.emit(':tell', this.t("STOP_MESSAGE"));
		},
		'AMAZON.StopIntent': function () {
			this.emit(':tell', this.t("STOP_MESSAGE"));
		},
		'Unhandled': function () {
			this.emit('AMAZON.HelpIntent');
		},
		'SessionEndedRequest': function () {
			console.log("Session ended");
		},
		':saveState': function (force) {
			// Methode saveState überlagert um das schreiben in die DynamoDB zu unterdrücken
			this.context.succeed(this.handler.response);
		}
	};

	function handleDiscovery(self) {

		handle(event, context, "discovery", "&customSkill=true", "GiraHS_Custom", function (ok, result) {
			var msg = "";

			if (ok) {
				if (result.header.name === 'DiscoverAppliancesResponse') {

					var discoveredAppliances = result.payload.discoveredAppliances;
					if (discoveredAppliances != null && discoveredAppliances.length > 0) {
						var appliances = {};
						for (var idx in discoveredAppliances) {
							var appliance = discoveredAppliances[idx];
							appliances[appliance['friendlyName'].toLowerCase()] = appliance['applianceId'];
						}
						self.attributes['APPLIANCES'] = JSON.stringify(appliances);
						msg = self.t('DIS_MESSAGE', discoveredAppliances.length);
					} else {
						msg = self.t('DIS_0_MESSAGE');
					}
				} else {
					msg = self.t('DIS_REQUEST_ERROR');
				}
			} else {
				msg = self.t('ERR_SYSTEM');
			}
			emit(self, msg);
		});
	}

	function handleGetRequest(self, params) {
		var property = resolveSlotValue(self, 'Property'); ;
		var praeposition = resolveSlotValue(self, 'Praeposition');
		var roomName = resolveSlotValue(self, 'Room');
		var article = resolveSlotValue(self, 'Article');
		var applianceName = resolveSlotValue(self, 'Appliance');
		var applianceSearchName = applianceName;

		// muss Anhand der Property auf das Objektt geschlossen werden?
		if (property != null) {
			if (applianceName == null) {
				applianceName = PROPERTY_MAP[property];
				if (applianceName != null) {
					applianceSearchName = applianceName;

					if (praeposition == null && article != null) {
						praeposition = ARTICLE_2_PRAEPOSITION[article];
					}
					article = "die";
				}
			} else {
				var prop = PROPERTY_MAP[property];
				if (prop != "") {
					article = "die";
					applianceName += " " + prop;
				}
			}
		}

		if (applianceSearchName == "temperatur") {
			params = GET_PARAMS['GetActualTemperature'];
			applianceSearchName = null;

		} else if (applianceSearchName == "solltemperatur") {
			params = GET_PARAMS['GetTargetTemperature'];
			applianceSearchName = null;
		}

		if (roomName == null && applianceName == null) { // nötige Parameter fehlen?
			emit(self, self.t('GET_PARAM_ERROR', params[5]));
			return;
		}

		// KNX-Objekt suchen
		var applianceId = findAppliance(self, roomName, applianceSearchName);
		if (applianceId == null) { // ID konnte nicht ermittelt werden?
			if (applianceName == "temperatur" || applianceName == "solltemperatur") {
				article = "das entsprechende";
				applianceName = "Objekt";
			}
			var p = process(article, applianceName, praeposition, roomName, false);
			emit(self, self.t('GET_NOT_FOUND_ERROR', params[5], p.article, p.applianceName, p.praeposition, p.roomName));
			return;
		}

		// Request an Logikbaustein senden
		var query = '&applianceId=' + encodeURIComponent(applianceId) + '&request=' + params[0];

		handle(event, context, "control", query, "GiraHS_Custom", function (ok, result) {
			var msg = '';

			if (!ok) { // Systemfehler aufgetreten?
				emit(self, msg = self.t('ERR_SYSTEM'));
				return;
			}

			if (result.header.name != params[1]) { // Anfrage konnte nicht fehlerfrei verarbeitet werden?
				var p = process(article, applianceName, praeposition, roomName, false);
				emit(self, self.t('GET_REQUEST_ERROR', params[5], p.article, p.applianceName, p.praeposition, p.roomName, buildRespErrMsg(self, result)));
				return;
			}

			var value = result.payload[params[2]].value;
			var unit = result.payload[params[2]].unit;

			if (params[3] == null) { // Meldung soll nicht aufbereitet werden?
				// => Meldung wie erhalten 1:1 ausgeben
				emit(self, params[4](value, unit));
				return;
			}

			var p = process(article, applianceName, praeposition, roomName, false);
			var msg = self.t('GET_OK', p.article, p.applianceName, p.praeposition, p.roomName, params[6], params[4](value, unit));
			console.log(msg);
			emit(self, msg);
		});
	}

	function handleSetOnOffRequest(self) {

		var switchValue = resolveSlotValue(self, 'SwitchValue');
		if (switchValue != null) {
			if (switchValue == 'an' || switchValue == 'ein') {
				handleSetRequest(self, SET_PARAMS['SetOn'], null);

			} else if (switchValue == "aus") {
				handleSetRequest(self, SET_PARAMS['SetOff'], null);

			} else {
				emit(self, self.t('SET_CMD_PARAM_ERROR', switchValue));
			}
		} else {
			emit(self, self.t('SET_ONOFF_PARAM_MISSING'));
		}
	}

	function handleSetPercentRequest(self) {

		var percentValue = resolveSlotValue(self, 'PercentValue');
		if (percentValue != null) {
			if (!isNaN(percentValue)) {
				handleSetRequest(self, SET_PARAMS['SetPercent'], percentValue);

			} else {
				emit(self, self.t('SET_PERCENT_PARAM_ILLEGAL', percentValue));
			}
		} else {
			emit(self, self.t('SET_PERCENT_PARAM_MISSING'));
		}
	}

	function handleSetRequest(self, params, value) {
		var praeposition = resolveSlotValue(self, 'Praeposition');
		var roomName = resolveSlotValue(self, 'Room');
		var article = resolveSlotValue(self, 'Article');
		var applianceName = resolveSlotValue(self, 'Appliance');

		if (roomName == null && applianceName == null) { // nötige Parameter fehlen?
			emit(self, self.t('SET_OBJECT_PARAM_MISSING', params[2]));
			return;
		}

		var applianceId = findAppliance(self, roomName, applianceName);
		if (applianceId == null) { // zu steuerndes Gerät nicht gefunden?
			var p = process(article, applianceName, praeposition, roomName, true);
			emit(self, self.t('SET_NOT_FOUND_ERROR', p.article, p.applianceName, p.praeposition, p.roomName, params[2]));
			return;
		}

		var query = '&applianceId=' + encodeURIComponent(applianceId) + '&request=' + params[0];
		if (value != null) {
			query += '&value=' + value;
		}

		handle(event, context, "control", query, "GiraHS_Custom", function (ok, result) {
			if (!ok) { // Serverfehler ?
				emit(self, self.t('ERR_SYSTEM'));
				return;
			}

			if (result.header.name != params[1]) { // Request liefert Fehler?
				var p = process(article, applianceName, praeposition, roomName, true);

				if (result.header.name == "UnsupportedOperationError") {
					emit(self, self.t('SET_CMD_NOT_SUPPORTED', p.applianceName, p.praeposition, p.roomName));
					return;
				}

				emit(self, self.t('SET_REQUEST_ERROR', p.article, p.applianceName, p.praeposition, p.roomName, params[2], buildRespErrMsg(self, result)));
				return;
			}
			emit(self, self.t('SET_OK'));
		});
	}

	function process(article, applianceName, praeposition, roomName, detail) {
		if (roomName != null) { // Bereich/Raumname angegeben?
			if (praeposition == null) { // Praeposition nicht angegeben?
				praeposition = detail ? "im Raum" : "im Bereich";
			}
		} else {
			praeposition = "";
			roomName = "";
		}

		if (applianceName != null) { // Objekt/Gerätename angegeben?
			if (article == null) { // Artikel nicht angegeben?
				article = detail ? "das Gerät" : "das Objekt";
			}
		} else {
			article = "";
			applianceName = "";
		}
		return {
			article: article,
			applianceName: applianceName,
			praeposition: praeposition,
			roomName: roomName
		};
	}

	function buildRespErrMsg(self, result) {
		var respErrMsg = "";

		if (result.header.name == "NoSuchTargetError") {
			var code = result.payload["error"].code;

			if (code == "AE_10") {
				respErrMsg = self.t('ERR_JSON_EMPTY');

			} else if (code == "AE_11") {
				var applianceId = result.payload["error"].applianceId;
				if (applianceId == null) {
					applianceId = "";
				}
				respErrMsg = self.t('ERR_ID_NOT_FOUND', applianceId);

			} else if (code == "AE_12") {
				var attributeName = result.payload["error"].attributeName;
				if (attributeName == null) {
					attributeName = "";
				}
				respErrMsg = self.t('ERR_ATTR_NOT_FOUND', attributeName);

			} else if (code == "AE_13") {
				var attributeValue = result.payload["error"].attributeValue;
				if (attributeValue == null) {
					attributeValue = "";
				}
				respErrMsg = self.t('ERR_KO_NOT_FOUND', attributeValue);
			}
		}
		return respErrMsg;
	}

	function resolveSlotValue(self, name) {
		var slot = self.event.request.intent.slots[name];
		if (slot && slot.value) {
			return slot.value.toLowerCase();
		}
		return null;
	}

	function findAppliance(self, roomName, applianceName) {
		var appliancesStr = self.attributes['APPLIANCES'];
		if (appliancesStr == null) {
			emit(self, self.t('ERR_NO_APPLIANCES'));
			return null;
		}

		var appliances = JSON.parse(appliancesStr);
		var applianceId = null;

		if (roomName != null) {
			if (applianceName != null) {
				var key = roomName + " " + applianceName;
				applianceId = appliances[key];
				if (applianceId == null) {
					key = applianceName + " " + roomName;
					applianceId = appliances[key];
				}
			} else {
				applianceId = appliances[roomName];
			}
		} else {
			applianceId = appliances[applianceName];
		}
		if (applianceId == null) {
			log('DEBUG', "roomName='" + roomName + "', applianceName='" + applianceName + "' not found in " + appliancesStr);
		}
		return applianceId;
	}

	function emit(self, msg) {
		if (self.attributes['IN_SESSION'] != null) {
			self.emit(':ask', msg, self.t('HELP_REPROMPT'));
		} else {
			self.emit(':tell', msg);
		}
	}
	// event.request
	// request.type === 'IntentRequest'
	// request.intent
	// intent.name
	// itent.slots
	// slots.Room

	// event.session
	// session.new : boolean

	var alexa = Alexa.handler(event, context);
	alexa.appId = APP_ID;
	alexa.resources = languageStrings;
	alexa.dynamoDBTableName = 'GiraHS';

	var request = event.request;
	if (request.type === 'IntentRequest' &&
		request.intent.name === 'DiscoverAppliances') {
		alexa.registerHandlers(discoveryHandlers);
	} else {
		alexa.registerHandlers(controlHandlers);
	}
	alexa.execute();
}

function handleSmartHomeSkill(event, context) {

	function handleRespone(ok, result) {
		if (ok) {
			context.succeed(result);
		} else {
			context.fail("Server Error");
		}
	}

	switch (event.header.namespace) {
	case 'Alexa.ConnectedHome.Discovery':
		handleDiscovery(event, context, handleRespone);
		break;

	case 'Alexa.ConnectedHome.Control':
		handleControl(event, context, handleRespone);
		break;

	default:
		log('Error', 'Unsupported namespace: ' + event.header.namespace);
		context.fail('Something went wrong');
		break;
	}
}

function handleDiscovery(event, context, cb) {
	var messageId = event.header.messageId;

	handle(event, context, "discovery", "", messageId, cb);
}

function handleControl(event, context, cb) {
	var request = event.header.name;
	var messageId = event.header.messageId;
	var applianceId = event.payload.appliance.applianceId;

	var query = '&applianceId=' + encodeURIComponent(applianceId) + '&request=' + request;

	if (request == "SetPercentageRequest") {
		query += '&value=' + event.payload.percentageState.value;

	} else if (request == "IncrementPercentageRequest" || request == "DecrementPercentageRequest") {
		query += '&value=' + event.payload.deltaPercentage.value;

	} else if (request == "SetTargetTemperatureRequest") {
		query += '&value=' + event.payload.targetTemperature.value;

	} else if (request == "IncrementTargetTemperatureRequest" || request == "DecrementTargetTemperatureRequest") {
		query += '&value=' + event.payload.targetTemperature.value;
	}

	handle(event, context, "control", query, messageId, cb);
}

function handle(event, context, path, query, messageId, cb) {

	path = REMOTE_CLOUD_BASE_PATH + path + '?accessToken=' + encodeURIComponent(ACCESS_TOKEN) + "&messageId=" + messageId + query;
	log('REQUEST', path);

	var options = {
		hostname: REMOTE_CLOUD_HOSTNAME,
		port: REMOTE_CLOUD_PORT,
		path: path,
		rejectUnauthorized: false,
		headers: {
			accept: '*/*'
		}
	};

	var callback = function (response) {
		var str = '';

		response.on('data', function (chunk) {
			str += chunk.toString('utf-8');
		});

		response.on('end', function () {
			log('RESPONSE', str);
			var result = JSON.parse(str);
			cb(true, result);
		});

		response.on('error', function (e) {
			log('Error', e.message);
			cb(false, null);
		});
	};

	https.get(options, callback).on('error', serverError).end();
}

function serverError(e) {
	log('Server Error', e.message);
}

function log(title, msg) {
	console.log("*** " + title + "***: " + msg);
}

function formatValue(value, format) {
	if (format == null) {
		return value;
	}
	format = format.trim();

	var fracSep = "";
	var fracDigStr = "";
	var fracDigCnt = -1;
	var unit = "";
	if (format.length >= 2 && (format[0] == '.' || format[0] == ',')) {
		fracSep = format[0];
		var i = 1;
		while (format[i] >= '0' && format[i] <= '9') {
			fracDigStr += format[i];
			++i;
		}
		if (i >= 2) {
			fracDigCnt = parseInt(fracDigStr);
		}
		unit = format.substr(i);
	} else {
		unit = format;
	}

	if (fracDigCnt == -1 || isNaN(value)) {
		return value + " " + unit;
	}

	if (!(typeof value == "number")) {
		value = parseFloat(value);
	}

	if (/^(\-|\+)?([0-9]+(\.[0-9]+)?|Infinity)$/.test(value)) {
		value = value.toFixed(fracDigCnt);

		if (fracDigCnt > 0) {
			var sign = "";
			var predec = "";
			var fracDig = "";

			var i = 0;

			if (value[i] == "-") {
				sign = "-";
				++i;
			}
			while (value[i] >= '0' && value[i] <= '9') {
				predec += value[i];
				++i;
			}
			++i;

			var j = 0;
			var sep = "";
			while (value[i + j] >= '0' && value[i + j] <= '9') {
				fracDig += sep + value[i + j];
				sep = " ";
				++j;
			}

			var digits = predec + fracDig;
			i = 0;
			var only0Digits = true;
			while (i < digits.length) {
				if (digits[i] != '0' && digits[i] != ' ') {
					only0Digits = false;
					break;
				}
				++i;
			}
			if (only0Digits) {
				sign = "";
			}

			value = sign + predec + fracSep + fracDig + " " + unit;
		} else {
			if (value == "-0") {
				value = "0";
			}
			value += unit;
		}

	} else {
		value = value + " " + unit;
	}

	return value;
}
